package exceptions.All;

public class EmptyCollectionException extends Exception{

	public EmptyCollectionException() {
		super();
	}
}
