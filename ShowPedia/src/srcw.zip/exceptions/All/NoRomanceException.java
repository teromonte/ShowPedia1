package exceptions.All;

public class NoRomanceException extends Exception{

	public NoRomanceException() {
		super();
	}
}
