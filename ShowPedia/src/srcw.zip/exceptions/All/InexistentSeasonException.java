package exceptions.All;

public class InexistentSeasonException extends Exception {

	public InexistentSeasonException() {
		super();
	}
	public InexistentSeasonException(String msg) {
		super(msg);
	}
}
