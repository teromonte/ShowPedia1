package exceptions.All;

public class RepeatedRelationShip extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public RepeatedRelationShip() {
		super();
	}
}
