package exceptions.All;

public class InexistentQuoteException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InexistentQuoteException() {
		super();
	}
}
