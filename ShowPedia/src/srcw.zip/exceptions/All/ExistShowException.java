package exceptions.All;

public class ExistShowException extends Exception {


	public ExistShowException (){
		super();
	}
}
