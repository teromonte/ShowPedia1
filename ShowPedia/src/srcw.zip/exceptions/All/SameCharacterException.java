package exceptions.All;

public class SameCharacterException extends Exception {

	public SameCharacterException() {
		super();
	}
}
