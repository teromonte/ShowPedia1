package object.Quote;

public interface Quote {

	/**
	 * 
	 * @return
	 */
	int getSeason();
	/**
	 * 
	 * @return
	 */
	int getEpisode() ;
	/**
	 * 
	 * @return
	 */
	String getCharacter();
	/**
	 * 
	 * @return
	 */
	String getQuote();
}
