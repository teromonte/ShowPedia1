package object.helpClass;

import java.util.Map;

public interface MapHelp<K,V> extends Map<K, V> {

}
