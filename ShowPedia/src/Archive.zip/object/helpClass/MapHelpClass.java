package object.helpClass;

import java.util.AbstractMap;
import java.util.Collection;
import java.util.HashMap;
import java.util.Set;

public class MapHelpClass<K,V> extends AbstractMap<K, V> {
	
	public MapHelpClass(){
		super();
	}
	

	@Override
	public boolean containsKey(Object key) {
		
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Set<Entry<K, V>> entrySet() {
		// TODO Auto-generated method stub
		return null;
	}
	

}
