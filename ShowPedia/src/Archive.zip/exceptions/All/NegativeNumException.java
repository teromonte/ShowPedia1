package exceptions.All;

public class NegativeNumException extends Exception {

	public NegativeNumException() {
		super();
	}
}
