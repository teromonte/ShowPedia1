package exceptions.All;

public class VirtualActorException  extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public VirtualActorException() {
		super();
	}
}
