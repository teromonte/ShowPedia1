package exceptions.All;

public class NotRelatedException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NotRelatedException() {
		super();
	}
}
