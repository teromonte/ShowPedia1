package exceptions.All;

public class UnknownActorTypeException extends Exception {

	public UnknownActorTypeException() {
		super();
	}
}
