package exceptions.All;

public class InexistentEpisodeNumber extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InexistentEpisodeNumber() {
		super();
	}
}
