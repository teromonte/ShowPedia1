package exceptions.All;

public class CharacterExistException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CharacterExistException() {
		super();
	}
}
